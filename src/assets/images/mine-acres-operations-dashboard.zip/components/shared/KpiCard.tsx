
import React from 'react';

interface KpiCardProps {
  title: string;
  value: string;
  // FIX: Replaced JSX.Element with React.ReactNode to resolve "Cannot find namespace 'JSX'" error.
  icon: React.ReactNode;
  unit?: string;
  className?: string;
}

const KpiCard: React.FC<KpiCardProps> = ({ title, value, icon, unit, className = '' }) => {
  return (
    <div className={`bg-brand-light border border-brand-accent p-4 rounded-lg shadow-md flex items-center ${className}`}>
      <div className="p-3 mr-4 text-gold bg-brand-accent rounded-full">
        {icon}
      </div>
      <div>
        <p className="text-sm text-gray-400 font-medium">{title}</p>
        <p className="text-2xl font-bold text-white">
          {value} <span className="text-lg font-medium text-gray-300">{unit}</span>
        </p>
      </div>
    </div>
  );
};

export default KpiCard;
