import React from 'react';
import SectionHeader from '../shared/SectionHeader';
import KpiCard from '../shared/KpiCard';
import DataTable from '../shared/DataTable';
import Card from '../shared/Card';
import { goldSales, contractorSales, pettyCashData } from '../../data/mockData';
import { GoldSale, ContractorSale, PettyCashEntry } from '../../types';
import { FinancialsIcon } from '../shared/Icons';

const currencyFormatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

const FinancialsSection: React.FC = () => {
    const Recharts = (window as any).Recharts;

    // --- Data Aggregation ---
    const totalMineAcresRevenue = goldSales.reduce((sum, item) => sum + item.cashReceived, 0);
    const totalContractorShare = contractorSales.reduce((sum, item) => sum + item.mineAcresShare, 0);
    const totalIncome = totalMineAcresRevenue + totalContractorShare;
    const totalPettyCash = pettyCashData.reduce((sum, item) => sum + item.amount, 0);
    const netCashFlow = totalIncome - totalPettyCash;
    
    const revenueSplitData = [
        { name: 'Mine Acres Production', value: totalMineAcresRevenue },
        { name: "Contractor Share (30%)", value: totalContractorShare },
    ];
    const COLORS = ['#FFD700', '#00C49F'];
    
    // --- Data Table Columns ---
    const goldSalesColumns = [
        { header: 'Date', accessor: (item: GoldSale) => item.date },
        { header: 'Source', accessor: (item: GoldSale) => item.source },
        { header: 'Gold Sold (g)', accessor: (item: GoldSale) => item.goldSold.toFixed(2) },
        { header: 'Cash Received', accessor: (item: GoldSale) => currencyFormatter.format(item.cashReceived) },
    ];

    const contractorSalesColumns = [
        { header: 'Date', accessor: (item: ContractorSale) => item.date },
        { header: 'Gross Sales', accessor: (item: ContractorSale) => currencyFormatter.format(item.grossSales) },
        { header: 'Expenses', accessor: (item: ContractorSale) => currencyFormatter.format(item.expenses) },
        { header: 'Mine Acres Share', accessor: (item: ContractorSale) => (
            <span className="font-bold text-green-400">{currencyFormatter.format(item.mineAcresShare)}</span>
        )},
    ];

    const pettyCashColumns = [
        { header: 'Date', accessor: (item: PettyCashEntry) => item.date },
        { header: 'Description', accessor: (item: PettyCashEntry) => item.description },
        { header: 'Amount', accessor: (item: PettyCashEntry) => currencyFormatter.format(item.amount) },
    ];
    
    const renderLineChart = () => {
        if (!Recharts) return <div className="h-[300px] flex items-center justify-center text-gray-400">Loading Chart...</div>;
        const { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } = Recharts;
        return (
            <ResponsiveContainer width="100%" height={300}>
                <LineChart data={goldSales.slice().reverse()}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#4A5568" />
                    <XAxis dataKey="date" tick={{ fill: '#A0AEC0' }} />
                    <YAxis tickFormatter={(tick) => `$${(tick/1000).toFixed(0)}k`} tick={{ fill: '#A0AEC0' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#2D3748', border: '1px solid #4A5568' }} formatter={(value: number) => currencyFormatter.format(value)} />
                    <Legend wrapperStyle={{ color: '#A0AEC0' }} />
                    <Line type="monotone" dataKey="cashReceived" name="Cash Received" stroke="#FFD700" strokeWidth={2} />
                </LineChart>
            </ResponsiveContainer>
        );
    };
    
    const renderPieChart = () => {
        if (!Recharts) return <div className="h-[300px] flex items-center justify-center text-gray-400">Loading Chart...</div>;
        const { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } = Recharts;
        return (
            <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                    <Pie data={revenueSplitData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={80} fill="#8884d8" paddingAngle={5}>
                        {revenueSplitData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#2D3748', border: '1px solid #4A5568' }} formatter={(value: number) => currencyFormatter.format(value)} />
                    <Legend wrapperStyle={{ color: '#A0AEC0' }} />
                </PieChart>
            </ResponsiveContainer>
        );
    };

    return (
        <div>
            <SectionHeader title="Financials" subtitle="Integrated dashboard linking production to financial outcomes." />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <KpiCard title="Total Income" value={currencyFormatter.format(totalIncome)} icon={<FinancialsIcon />} className="lg:col-span-2" />
                <KpiCard title="Total Expenses" value={currencyFormatter.format(totalPettyCash)} icon={<FinancialsIcon />} />
                <KpiCard title="Net Cash Flow" value={currencyFormatter.format(netCashFlow)} icon={<FinancialsIcon />} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                 <Card title="Gold Sales Trend" className="lg:col-span-2">
                    {renderLineChart()}
                </Card>
                <Card title="Total Revenue Split">
                     {renderPieChart()}
                </Card>
            </div>
            
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-6">
                 <DataTable columns={goldSalesColumns} data={goldSales} title="Mine Acres Gold Sales" />
                 <DataTable columns={contractorSalesColumns} data={contractorSales} title="Contractor Sales & Share" />
            </div>
            <DataTable columns={pettyCashColumns} data={pettyCashData} title="Petty Cash Ledger" />

        </div>
    );
};

export default FinancialsSection;