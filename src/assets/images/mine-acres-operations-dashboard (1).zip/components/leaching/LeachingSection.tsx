import React from 'react';
import SectionHeader from '../shared/SectionHeader';
import KpiCard from '../shared/KpiCard';
import DataTable from '../shared/DataTable';
import Card from '../shared/Card';
import { leachingData, chemicalTests } from '../../data/mockData';
import { LeachingVatRecord } from '../../types';
import { LeachingIcon } from '../shared/Icons';

const LeachingSection: React.FC = () => {
    const Recharts = (window as any).Recharts;
    // --- Data Aggregation ---
    const latestVat = leachingData[0];
    const avgRecovery = leachingData.reduce((sum, item) => sum + item.labResult, 0) / leachingData.length;

    // --- Data Table Columns ---
    const vatColumns = [
        { header: 'Vat ID', accessor: (item: LeachingVatRecord) => item.vatId },
        { header: 'Start Date', accessor: (item: LeachingVatRecord) => item.startDate },
        { header: 'End Date', accessor: (item: LeachingVatRecord) => item.endDate },
        { header: 'Tonnage', accessor: (item: LeachingVatRecord) => item.tonnageLoaded.toFixed(2) },
        { header: 'Cyanide (kg)', accessor: (item: LeachingVatRecord) => item.chemicalsUsed.cyanide.toFixed(2) },
        { header: 'Caustic (kg)', accessor: (item: LeachingVatRecord) => item.chemicalsUsed.causticSoda.toFixed(2) },
        { header: 'Recovery (g/t)', accessor: (item: LeachingVatRecord) => (
            <span className="font-bold text-gold">{item.labResult.toFixed(2)}</span>
        )},
    ];
    
    const renderComposedChart = () => {
        if (!Recharts) return <div className="h-[300px] flex items-center justify-center text-gray-400">Loading Chart...</div>;
        const { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } = Recharts;
        return (
            <ResponsiveContainer width="100%" height={300}>
                <ComposedChart data={leachingData.slice().reverse()}>
                     <CartesianGrid strokeDasharray="3 3" stroke="#4A5568" />
                    <XAxis dataKey="vatId" tick={{ fill: '#A0AEC0' }} />
                    <YAxis yAxisId="left" label={{ value: 'g/t', angle: -90, position: 'insideLeft', fill: '#A0AEC0' }} tick={{ fill: '#A0AEC0' }} />
                    <YAxis yAxisId="right" orientation="right" label={{ value: 'Tons', angle: -90, position: 'insideRight', fill: '#A0AEC0' }} tick={{ fill: '#A0AEC0' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#2D3748', border: '1px solid #4A5568' }} />
                    <Legend wrapperStyle={{ color: '#A0AEC0' }} />
                    <Bar yAxisId="right" dataKey="tonnageLoaded" name="Tonnage" fill="#4A5568" />
                    <Line yAxisId="left" type="monotone" dataKey="labResult" name="Recovery (g/t)" stroke="#FFD700" strokeWidth={2} />
                </ComposedChart>
            </ResponsiveContainer>
        );
    };
    
    const renderLineChart = () => {
        if (!Recharts) return <div className="h-[300px] flex items-center justify-center text-gray-400">Loading Chart...</div>;
        const { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } = Recharts;
        return (
            <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chemicalTests}>
                     <CartesianGrid strokeDasharray="3 3" stroke="#4A5568" />
                    <XAxis dataKey="date" tick={{ fill: '#A0AEC0' }} />
                    <YAxis tick={{ fill: '#A0AEC0' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#2D3748', border: '1px solid #4A5568' }} />
                    <Legend wrapperStyle={{ color: '#A0AEC0' }} />
                    <Line type="monotone" dataKey="ph" name="pH Level" stroke="#3182CE" />
                    <Line type="monotone" dataKey="cyanideStrength" name="Cyanide Strength" stroke="#38A169" />
                </LineChart>
            </ResponsiveContainer>
        );
    };

    return (
        <div>
            <SectionHeader title="Leaching Plant Operations" subtitle="Recovery performance, chemical usage, and process monitoring." />
            
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <KpiCard title="Latest Recovery" value={latestVat.labResult.toFixed(2)} unit="g/t" icon={<LeachingIcon />} />
                <KpiCard title="Avg. Recovery" value={avgRecovery.toFixed(2)} unit="g/t" icon={<LeachingIcon />} />
                <KpiCard title="Active Vats" value={leachingData.length.toString()} icon={<LeachingIcon />} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                 <Card title="Recovery Performance per Vat">
                    {renderComposedChart()}
                </Card>
                 <Card title="Chemical Tests (Last 30 Days)">
                    {renderLineChart()}
                </Card>
            </div>
            
            <DataTable columns={vatColumns} data={leachingData} title="Leaching Cycle History" />

        </div>
    );
};

export default LeachingSection;