
import { DailyMiningRecord, MillingShiftRecord, DowntimeRecord, LeachingVatRecord, ChemicalTest, ServiceRecord, StockItem, GoldSale, ContractorSale, PettyCashEntry } from '../types';

const claims: DailyMiningRecord['claimName'][] = ['Cowslip 37', 'Cowslip 37B', 'Cowslip 37A', 'Cowslip 15', 'Comedy SW14'];
const machines = ['Crusher', 'Mill 1', 'Conveyor Belt', 'Pump A', 'Loader'];

const random = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
const randomFloat = (min: number, max: number) => parseFloat((Math.random() * (max - min) + min).toFixed(2));

const generateDailyData = <T,>(days: number, generator: (date: Date) => T[]): T[] => {
  const data: T[] = [];
  const today = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    data.push(...generator(date));
  }
  return data;
};

export const miningData: DailyMiningRecord[] = generateDailyData(30, (date) => {
    const records: DailyMiningRecord[] = [];
    const numRecords = random(2, 4);
    for(let i = 0; i < numRecords; i++) {
        const isMA = Math.random() > 0.4;
        records.push({
            date: date.toISOString().split('T')[0],
            claimName: claims[random(0, claims.length - 1)],
            productionType: isMA ? 'Mine Acres' : 'Contractor',
            explosivesUsed: random(50, 200),
            dieselUsed: random(100, 500),
            tonnageHoisted: {
                oreMineAcres: isMA ? random(20, 80) : 0,
                oreContractor: !isMA ? random(30, 100) : 0,
                waste: random(10, 50),
            },
            tonnageHauled: random(80, 200),
        });
    }
    return records;
});


export const millingData: MillingShiftRecord[] = generateDailyData(30, (date) => [
  {
    date: date.toISOString().split('T')[0],
    shift: 'Day',
    tonnageReceived: { mineAcres: random(40, 100), contractor: random(50, 120) },
    tonnageMilled: random(100, 200),
  },
  {
    date: date.toISOString().split('T')[0],
    shift: 'Night',
    tonnageReceived: { mineAcres: random(30, 90), contractor: random(40, 110) },
    tonnageMilled: random(90, 180),
  },
]);

export const downtimeData: DowntimeRecord[] = generateDailyData(30, (date) => {
    if (Math.random() > 0.7) {
        return [{
            id: `dt-${date.getTime()}`,
            date: date.toISOString().split('T')[0],
            duration: randomFloat(0.5, 4),
            cause: ['Mechanical Failure', 'Power Outage', 'Scheduled Maintenance', 'Operator Error'][random(0, 3)],
            machine: machines[random(0, machines.length - 1)],
        }];
    }
    return [];
});

export const leachingData: LeachingVatRecord[] = Array.from({ length: 10 }, (_, i) => {
    const endDate = new Date();
    endDate.setDate(endDate.getDate() - i * 5);
    const startDate = new Date(endDate);
    startDate.setDate(startDate.getDate() - 5);
    return {
        vatId: `VAT-0${i + 1}`,
        startDate: startDate.toISOString().split('T')[0],
        endDate: endDate.toISOString().split('T')[0],
        tonnageLoaded: random(500, 800),
        chemicalsUsed: {
            cyanide: random(100, 250),
            causticSoda: random(80, 200),
        },
        labResult: randomFloat(1.5, 4.0),
    };
});

export const chemicalTests: ChemicalTest[] = generateDailyData(30, (date) => [{
  date: date.toISOString().split('T')[0],
  ph: randomFloat(10.5, 11.5),
  cyanideStrength: randomFloat(0.05, 0.15),
}]);

export const serviceRecords: ServiceRecord[] = Array.from({ length: 15 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - random(1, 90));
    return {
        id: `sr-${i}`,
        date: date.toISOString().split('T')[0],
        machine: machines[random(0, machines.length - 1)],
        remarks: ['Routine check', 'Replaced bearing', 'Oil change', 'Filter cleaned'][random(0, 3)],
    };
}).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());


export const stockItems: StockItem[] = [
    { id: 's1', name: 'Engine Oil (20L)', category: 'Lubricants', quantity: 15, reorderThreshold: 10 },
    { id: 's2', name: 'Bearings (SKF-222)', category: 'Spare Parts', quantity: 8, reorderThreshold: 5 },
    { id: 's3', name: 'V-Belts (B52)', category: 'Spare Parts', quantity: 25, reorderThreshold: 20 },
    { id: 's4', name: 'Hydraulic Fluid', category: 'Lubricants', quantity: 5, reorderThreshold: 8 },
    { id: 's5', name: 'Welding Rods (box)', category: 'Consumables', quantity: 30, reorderThreshold: 20 },
    { id: 's6', name: 'Grinding Media (kg)', category: 'Consumables', quantity: 2500, reorderThreshold: 1000 },
];

export const goldSales: GoldSale[] = Array.from({ length: 8 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - i * 14);
    const gold = random(500, 2000);
    return {
        cycleId: `SALE-${100 + i}`,
        date: date.toISOString().split('T')[0],
        source: Math.random() > 0.5 ? 'Milling' : 'Leaching',
        goldSold: gold,
        cashReceived: gold * randomFloat(68.5, 72.3),
    };
});

export const contractorSales: ContractorSale[] = goldSales.map((sale, i) => {
    const gross = random(20000, 50000);
    const expenses = gross * randomFloat(0.1, 0.25);
    return {
        cycleId: `CSALE-${100 + i}`,
        date: sale.date,
        grossSales: gross,
        expenses: expenses,
        mineAcresShare: (gross - expenses) * 0.3,
    };
});

export const pettyCashData: PettyCashEntry[] = generateDailyData(45, (date) => {
    const entries: PettyCashEntry[] = [];
    const numEntries = random(0, 4);
    for (let i = 0; i < numEntries; i++) {
        entries.push({
            id: `pc-${date.getTime()}-${i}`,
            date: date.toISOString().split('T')[0],
            description: ['Fuel for Generator', 'Groceries', 'Small tool purchase', 'Transport', 'Repairs'][random(0, 4)],
            amount: random(20, 300),
        });
    }
    return entries;
}).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
