import React from 'react';
import SectionHeader from '../shared/SectionHeader';
import KpiCard from '../shared/KpiCard';
import DataTable from '../shared/DataTable';
import Card from '../shared/Card';
import { millingData, downtimeData } from '../../data/mockData';
import { DowntimeRecord } from '../../types';
import { MillingIcon } from '../shared/Icons';

const MillingSection: React.FC = () => {
    const Recharts = (window as any).Recharts;

    // --- Data Aggregation ---
    const today = new Date().toISOString().split('T')[0];
    const todaysMilling = millingData.filter(d => d.date === today);
    const totalMilledToday = todaysMilling.reduce((acc, curr) => acc + curr.tonnageMilled, 0);

    const shiftData = millingData.slice(-14).reduce((acc, curr) => {
        const key = `${curr.date}-${curr.shift}`;
        if (!acc[key]) {
            acc[key] = { date: curr.date, shift: curr.shift, milled: 0 };
        }
        acc[key].milled += curr.tonnageMilled;
        return acc;
    }, {} as { [key: string]: { date: string, shift: string, milled: number } });

    const shiftChartData = Object.values(shiftData).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    const downtimeByCause = downtimeData.reduce((acc, curr) => {
        acc[curr.cause] = (acc[curr.cause] || 0) + curr.duration;
        return acc;
    }, {} as { [key: string]: number });
    
    const downtimeChartData = Object.entries(downtimeByCause).map(([name, value]) => ({ name, value }));
    const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];
    const totalDowntimeHours = downtimeData.reduce((sum, item) => sum + item.duration, 0);
    const millTarget = 400;
    const performance = totalMilledToday > 0 ? (totalMilledToday / millTarget) * 100 : 0;


    // --- Data Table Columns ---
    const downtimeColumns = [
        { header: 'Date', accessor: (item: DowntimeRecord) => item.date },
        { header: 'Machine', accessor: (item: DowntimeRecord) => item.machine },
        { header: 'Cause', accessor: (item: DowntimeRecord) => item.cause },
        { header: 'Duration (hrs)', accessor: (item: DowntimeRecord) => item.duration.toFixed(2) },
    ];
    
    const renderBarChart = () => {
        if (!Recharts) return <div className="h-[300px] flex items-center justify-center text-gray-400">Loading Chart...</div>;
        const { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } = Recharts;
        return (
            <ResponsiveContainer width="100%" height={300}>
                <BarChart data={shiftChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#4A5568" />
                    <XAxis dataKey="date" tick={{ fill: '#A0AEC0' }} />
                    <YAxis tick={{ fill: '#A0AEC0' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#2D3748', border: '1px solid #4A5568' }} />
                    <Legend wrapperStyle={{ color: '#A0AEC0' }} />
                    <Bar dataKey="milled" name="Tonnage Milled" fill="#8884d8" />
                </BarChart>
            </ResponsiveContainer>
        );
    };
    
    const renderPieChart = () => {
        if (!Recharts) return <div className="h-[300px] flex items-center justify-center text-gray-400">Loading Chart...</div>;
        const { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } = Recharts;
        return (
            <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                    <Pie data={downtimeChartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} fill="#8884d8">
                        {downtimeChartData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                    </Pie>
                     <Tooltip contentStyle={{ backgroundColor: '#2D3748', border: '1px solid #4A5568' }} formatter={(value: number) => `${value.toFixed(2)} hrs`} />
                     <Legend wrapperStyle={{ color: '#A0AEC0' }} />
                </PieChart>
            </ResponsiveContainer>
        );
    };

    return (
        <div>
            <SectionHeader title="Milling Plant Operations" subtitle="Shift-based performance, efficiency, and downtime analysis." />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <KpiCard title="Total Milled Today" value={totalMilledToday.toFixed(2)} unit="T" icon={<MillingIcon />} />
                <KpiCard title="Total Downtime (30d)" value={totalDowntimeHours.toFixed(2)} unit="Hrs" icon={<MillingIcon />} />
                <KpiCard title="Performance vs Target" value={performance.toFixed(1)} unit="%" icon={<MillingIcon />} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                <Card title="Shift Output (Last 7 Days)" className="lg:col-span-2">
                    {renderBarChart()}
                </Card>
                <Card title="Downtime by Cause">
                    {renderPieChart()}
                </Card>
            </div>
            
            <DataTable columns={downtimeColumns} data={downtimeData.slice().reverse()} title="Recent Downtime Events"/>
        </div>
    );
};

export default MillingSection;