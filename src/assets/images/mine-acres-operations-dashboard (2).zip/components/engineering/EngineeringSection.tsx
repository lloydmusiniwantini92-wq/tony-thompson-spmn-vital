
import React from 'react';
import SectionHeader from '../shared/SectionHeader';
import DataTable from '../shared/DataTable';
import Card from '../shared/Card';
import { serviceRecords, stockItems } from '../../data/mockData';
import { ServiceRecord, StockItem } from '../../types';

const StockLevelBar: React.FC<{ item: StockItem }> = ({ item }) => {
    const percentage = (item.quantity / (item.reorderThreshold * 1.5)) * 100;
    const isLow = item.quantity <= item.reorderThreshold;
    const barColor = isLow ? 'bg-red-500' : 'bg-green-500';

    return (
        <div className="w-full">
            <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-300">{item.quantity} units</span>
                {isLow && <span className="text-sm font-medium text-red-400">Re-order!</span>}
            </div>
            <div className="w-full bg-brand-accent rounded-full h-2.5">
                <div className={`${barColor} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
            </div>
        </div>
    );
};

const EngineeringSection: React.FC = () => {

    const serviceColumns = [
        { header: 'Date', accessor: (item: ServiceRecord) => item.date },
        { header: 'Machine', accessor: (item: ServiceRecord) => item.machine },
        { header: 'Remarks', accessor: (item: ServiceRecord) => item.remarks },
    ];
    
    const stockColumns = [
        { header: 'Item Name', accessor: (item: StockItem) => item.name },
        { header: 'Category', accessor: (item: StockItem) => item.category },
        { header: 'Stock Level', accessor: (item: StockItem) => <StockLevelBar item={item} /> },
    ];

    return (
        <div>
            <SectionHeader title="Engineering & Maintenance" subtitle="Service records and inventory monitoring." />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <DataTable columns={stockColumns} data={stockItems} title="Stock In Hand" />
                <DataTable columns={serviceColumns} data={serviceRecords} title="Recent Service Records" />
            </div>
        </div>
    );
};

export default EngineeringSection;
