import React from 'react';
import SectionHeader from '../shared/SectionHeader';
import KpiCard from '../shared/KpiCard';
import DataTable from '../shared/DataTable';
import Card from '../shared/Card';
import { miningData } from '../../data/mockData';
import { DailyMiningRecord } from '../../types';
import { TruckIcon, CubeIcon, TrashIcon } from '../shared/Icons';

const MiningSection: React.FC = () => {
    const Recharts = (window as any).Recharts;

    // --- Data Aggregation ---
    const today = new Date().toISOString().split('T')[0];
    const todaysData = miningData.filter(d => d.date === today);

    const totalOreHoistedToday = todaysData.reduce((acc, curr) => acc + curr.tonnageHoisted.oreMineAcres + curr.tonnageHoisted.oreContractor, 0);
    const totalWasteToday = todaysData.reduce((acc, curr) => acc + curr.tonnageHoisted.waste, 0);
    const totalHauledToday = todaysData.reduce((acc, curr) => acc + curr.tonnageHauled, 0);

    const monthlySummary = miningData.reduce((acc, curr) => {
        const date = curr.date;
        if (!acc[date]) {
            acc[date] = { date, mineAcres: 0, contractor: 0, waste: 0 };
        }
        acc[date].mineAcres += curr.tonnageHoisted.oreMineAcres;
        acc[date].contractor += curr.tonnageHoisted.oreContractor;
        acc[date].waste += curr.tonnageHoisted.waste;
        return acc;
    }, {} as { [key: string]: { date: string, mineAcres: number, contractor: number, waste: number } });

    const productionTrendData = Object.values(monthlySummary).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    const totalMineAcresOre = miningData.reduce((sum, item) => sum + item.tonnageHoisted.oreMineAcres, 0);
    const totalContractorOre = miningData.reduce((sum, item) => sum + item.tonnageHoisted.oreContractor, 0);
    const totalWaste = miningData.reduce((sum, item) => sum + item.tonnageHoisted.waste, 0);
    
    const oreWasteRatioData = [
        { name: 'Mine Acres Ore', value: totalMineAcresOre },
        { name: 'Contractor Ore', value: totalContractorOre },
        { name: 'Waste', value: totalWaste },
    ];
    const COLORS = ['#0088FE', '#00C49F', '#FF8042'];

    // --- Data Table Columns ---
    const columns = [
        { header: 'Date', accessor: (item: DailyMiningRecord) => item.date },
        { header: 'Claim', accessor: (item: DailyMiningRecord) => item.claimName },
        { header: 'Type', accessor: (item: DailyMiningRecord) => (
            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.productionType === 'Mine Acres' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>
                {item.productionType}
            </span>
        ) },
        { header: 'Ore Hoisted (T)', accessor: (item: DailyMiningRecord) => (item.tonnageHoisted.oreMineAcres + item.tonnageHoisted.oreContractor).toFixed(2) },
        { header: 'Waste (T)', accessor: (item: DailyMiningRecord) => item.tonnageHoisted.waste.toFixed(2) },
        { header: 'Hauled (T)', accessor: (item: DailyMiningRecord) => item.tonnageHauled.toFixed(2) },
    ];
    
    const renderLineChart = () => {
        if (!Recharts) return <div className="h-[300px] flex items-center justify-center text-gray-400">Loading Chart...</div>;
        const { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } = Recharts;
        return (
            <ResponsiveContainer width="100%" height={300}>
                <LineChart data={productionTrendData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#4A5568" />
                    <XAxis dataKey="date" tick={{ fill: '#A0AEC0' }} />
                    <YAxis tick={{ fill: '#A0AEC0' }} />
                    <Tooltip contentStyle={{ backgroundColor: '#2D3748', border: '1px solid #4A5568' }} />
                    <Legend wrapperStyle={{ color: '#A0AEC0' }} />
                    <Line type="monotone" dataKey="mineAcres" name="Mine Acres Ore" stroke="#3182CE" strokeWidth={2} />
                    <Line type="monotone" dataKey="contractor" name="Contractor Ore" stroke="#38A169" strokeWidth={2} />
                </LineChart>
            </ResponsiveContainer>
        );
    };
    
    const renderPieChart = () => {
        if (!Recharts) return <div className="h-[300px] flex items-center justify-center text-gray-400">Loading Chart...</div>;
        const { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } = Recharts;
        return (
            <ResponsiveContainer width="100%" height={300}>
                 <PieChart>
                    <Pie data={oreWasteRatioData} cx="50%" cy="50%" labelLine={false} outerRadius={80} fill="#8884d8" dataKey="value" nameKey="name">
                        {oreWasteRatioData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#2D3748', border: '1px solid #4A5568' }} />
                    <Legend wrapperStyle={{ color: '#A0AEC0' }} />
                </PieChart>
            </ResponsiveContainer>
        );
    };

    return (
        <div>
            <SectionHeader title="Mining Operations" subtitle="Daily and monthly summaries of production and material movement." />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                <KpiCard title="Ore Hoisted Today" value={totalOreHoistedToday.toFixed(2)} unit="T" icon={<CubeIcon />} />
                <KpiCard title="Waste Hoisted Today" value={totalWasteToday.toFixed(2)} unit="T" icon={<TrashIcon />} />
                <KpiCard title="Total Hauled Today" value={totalHauledToday.toFixed(2)} unit="T" icon={<TruckIcon />} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                <Card title="Daily Production Trend (Last 30 Days)" className="lg:col-span-2">
                    {renderLineChart()}
                </Card>
                <Card title="Monthly Material Ratio">
                    {renderPieChart()}
                </Card>
            </div>

            <DataTable columns={columns} data={miningData.slice().reverse()} title="Recent Mining Activity" />
        </div>
    );
};

export default MiningSection;