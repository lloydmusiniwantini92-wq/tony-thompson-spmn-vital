
import React, { useState } from 'react';
import MiningSection from './components/mining/MiningSection';
import MillingSection from './components/milling/MillingSection';
import LeachingSection from './components/leaching/LeachingSection';
import EngineeringSection from './components/engineering/EngineeringSection';
import FinancialsSection from './components/financials/FinancialsSection';
import { MiningDataIcon, MillingIcon, LeachingIcon, EngineeringIcon, FinancialsIcon } from './components/shared/Icons';
import Logo from './components/shared/Logo';

type Section = 'Mining' | 'Milling' | 'Leaching' | 'Engineering' | 'Financials';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<Section>('Mining');

  const renderSection = () => {
    switch (activeSection) {
      case 'Mining':
        return <MiningSection />;
      case 'Milling':
        return <MillingSection />;
      case 'Leaching':
        return <LeachingSection />;
      case 'Engineering':
        return <EngineeringSection />;
      case 'Financials':
        return <FinancialsSection />;
      default:
        return <MiningSection />;
    }
  };

  // FIX: Replaced JSX.Element with React.ReactNode to resolve "Cannot find namespace 'JSX'" error.
  const navItems: { name: Section; icon: React.ReactNode }[] = [
    { name: 'Mining', icon: <MiningDataIcon /> },
    { name: 'Milling', icon: <MillingIcon /> },
    { name: 'Leaching', icon: <LeachingIcon /> },
    { name: 'Engineering', icon: <EngineeringIcon /> },
    { name: 'Financials', icon: <FinancialsIcon /> },
  ];

  return (
    <div className="min-h-screen bg-brand-dark text-gray-200 font-sans">
      <header className="bg-brand-light p-4 shadow-lg sticky top-0 z-10">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Logo />
            <h1 className="text-xl md:text-2xl font-bold text-gold">Mine Acres Operations</h1>
          </div>
          <nav className="hidden md:flex space-x-1">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => setActiveSection(item.name)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                  activeSection === item.name
                    ? 'bg-gold text-brand-dark'
                    : 'text-gray-300 hover:bg-brand-accent hover:text-white'
                }`}
              >
                {item.name}
              </button>
            ))}
          </nav>
        </div>
      </header>
      
      <main className="container mx-auto p-4 md:p-6">
        {renderSection()}
      </main>

      {/* Mobile Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-brand-light border-t border-brand-accent shadow-lg flex justify-around">
        {navItems.map((item) => (
          <button
            key={item.name}
            onClick={() => setActiveSection(item.name)}
            className={`flex flex-col items-center justify-center p-2 w-full transition-colors duration-200 ${
              activeSection === item.name ? 'text-gold' : 'text-gray-400 hover:text-white'
            }`}
          >
            {item.icon}
            <span className="text-xs mt-1">{item.name}</span>
          </button>
        ))}
      </nav>
      <div className="h-16 md:hidden"></div> {/* Spacer for mobile nav */}
    </div>
  );
};

export default App;
