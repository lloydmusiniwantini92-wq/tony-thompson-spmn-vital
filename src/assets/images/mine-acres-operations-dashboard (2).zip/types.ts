
export interface DailyMiningRecord {
  date: string;
  claimName: 'Cowslip 37' | 'Cowslip 37B' | 'Cowslip 37A' | 'Cowslip 15' | 'Comedy SW14';
  productionType: 'Mine Acres' | 'Contractor';
  explosivesUsed: number;
  dieselUsed: number;
  tonnageHoisted: {
    oreMineAcres: number;
    oreContractor: number;
    waste: number;
  };
  tonnageHauled: number;
}

export interface MillingShiftRecord {
  date: string;
  shift: 'Day' | 'Night';
  tonnageReceived: {
    mineAcres: number;
    contractor: number;
  };
  tonnageMilled: number;
}

export interface DowntimeRecord {
  id: string;
  date: string;
  duration: number; // in hours
  cause: string;
  machine: string;
}

export interface LeachingVatRecord {
  vatId: string;
  startDate: string;
  endDate: string;
  tonnageLoaded: number;
  chemicalsUsed: {
    cyanide: number; // kg
    causticSoda: number; // kg
  };
  labResult: number; // g/t
}

export interface ChemicalTest {
  date: string;
  ph: number;
  cyanideStrength: number;
}

export interface ServiceRecord {
  id: string;
  date: string;
  machine: string;
  remarks: string;
}

export interface StockItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  reorderThreshold: number;
}

export interface GoldSale {
  cycleId: string;
  date: string;
  source: 'Milling' | 'Leaching';
  goldSold: number; // grams
  cashReceived: number; // USD
}

export interface ContractorSale {
    cycleId: string;
    date: string;
    grossSales: number;
    expenses: number;
    mineAcresShare: number; // calculated
}

export interface PettyCashEntry {
    id: string;
    date: string;
    description: string;
    amount: number;
}
