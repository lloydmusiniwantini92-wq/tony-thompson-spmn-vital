import React from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

const BrainDump: React.FC = () => {
  const [notes, setNotes] = useLocalStorage('braindump_notes', '');

  return (
    <div className="p-4 h-full flex flex-col">
      <h1 className="text-3xl font-bold text-app-text px-2 pb-4">Brain Dump</h1>
      <div className="flex-grow">
        <textarea
          value={notes}
          onChange={e => setNotes(e.target.value)}
          placeholder="What's on your mind? Get it all out here..."
          className="w-full h-full p-3 bg-app-card border border-app-border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-app-primary resize-none text-lg leading-relaxed"
        />
      </div>
    </div>
  );
};

export default BrainDump;
