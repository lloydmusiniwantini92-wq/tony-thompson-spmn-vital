import React, { useState, useEffect, useMemo } from 'react';
import { PlayIcon, PauseIcon, ResetIcon } from './shared/Icons';

const FOCUS_TIME = 25 * 60; // 25 minutes
const BREAK_TIME = 5 * 60; // 5 minutes

type TimerMode = 'Focus' | 'Break';

const Focus: React.FC = () => {
  const [mode, setMode] = useState<TimerMode>('Focus');
  const [time, setTime] = useState(FOCUS_TIME);
  const [isActive, setIsActive] = useState(false);

  const duration = useMemo(() => (mode === 'Focus' ? FOCUS_TIME : BREAK_TIME), [mode]);
  const progress = (duration - time) / duration;
  const circumference = 2 * Math.PI * 120;
  const strokeDashoffset = circumference * (1 - progress);

  useEffect(() => {
    // FIX: Use ReturnType<typeof setInterval> for the interval ID type, which is more portable than NodeJS.Timeout for browser environments.
    let interval: ReturnType<typeof setInterval> | null = null;
    if (isActive && time > 0) {
      interval = setInterval(() => {
        setTime(t => t - 1);
      }, 1000);
    } else if (time === 0) {
      // Simple notification for mode switch
      new Audio('https://interactive-examples.mdn.mozilla.net/media/cc0-audio/t-rex-roar.mp3').play();
      const newMode: TimerMode = mode === 'Focus' ? 'Break' : 'Focus';
      setMode(newMode);
      setTime(newMode === 'Focus' ? FOCUS_TIME : BREAK_TIME);
      setIsActive(false);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, time, mode]);

  const toggleTimer = () => setIsActive(!isActive);

  const resetTimer = () => {
    setIsActive(false);
    setTime(duration);
  };

  const minutes = Math.floor(time / 60);
  const seconds = time % 60;

  return (
    <div className="p-4 h-full flex flex-col items-center justify-center text-center">
      <h1 className="text-3xl font-bold text-app-text mb-4">{mode} Session</h1>
      <p className="text-app-text-subtle mb-8">
        {mode === 'Focus' ? 'Time to lock in and get it done.' : 'Time for a short break. You earned it!'}
      </p>

      <div className="relative w-72 h-72 flex items-center justify-center">
        <svg className="absolute w-full h-full" viewBox="0 0 250 250">
          <circle cx="125" cy="125" r="120" stroke="#E5E5EA" strokeWidth="10" fill="transparent" />
          <circle
            cx="125"
            cy="125"
            r="120"
            stroke={mode === 'Focus' ? '#007AFF' : '#34C759'}
            strokeWidth="10"
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            transform="rotate(-90 125 125)"
            className="transition-all duration-1000"
          />
        </svg>
        <div className="text-6xl font-bold text-app-text tracking-tighter">
          {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
        </div>
      </div>

      <div className="flex items-center gap-8 mt-10">
        <button onClick={resetTimer} className="text-app-text-subtle hover:text-app-primary transition-colors">
            <ResetIcon />
        </button>
        <button onClick={toggleTimer} className={`text-5xl ${mode === 'Focus' ? 'text-app-primary' : 'text-app-accent'}`}>
          {isActive ? <PauseIcon /> : <PlayIcon />}
        </button>
        <div className="w-6"></div>
      </div>
    </div>
  );
};

export default Focus;