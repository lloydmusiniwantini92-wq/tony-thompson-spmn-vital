import React, { useState } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Task } from '../types';
import { PlusIcon, TrashIcon } from './shared/Icons';

const Tasks: React.FC = () => {
  const [tasks, setTasks] = useLocalStorage<Task[]>('tasks', []);
  const [newTaskText, setNewTaskText] = useState('');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskText.trim() === '') return;
    const newTask: Task = {
      id: Date.now().toString(),
      text: newTaskText.trim(),
      completed: false,
    };
    setTasks([newTask, ...tasks]);
    setNewTaskText('');
  };

  const toggleTask = (id: string) => {
    setTasks(
      tasks.map(task =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  return (
    <div className="p-4 h-full flex flex-col">
      <h1 className="text-3xl font-bold text-app-text px-2 pb-4">Tasks</h1>
      <form onSubmit={handleAddTask} className="flex items-center gap-2 mb-4">
        <input
          type="text"
          value={newTaskText}
          onChange={e => setNewTaskText(e.target.value)}
          placeholder="Add a new task..."
          className="flex-grow p-3 bg-app-card border border-app-border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-app-primary"
        />
        <button type="submit" className="p-3 bg-app-primary text-white rounded-lg shadow-sm hover:bg-opacity-90 transition-all">
          <PlusIcon />
        </button>
      </form>
      <div className="flex-grow overflow-y-auto pr-1">
        {tasks.length === 0 && (
          <div className="text-center py-10 text-app-text-subtle">
            <p>No tasks yet. Add one above!</p>
          </div>
        )}
        <ul>
          {tasks.map(task => (
            <li
              key={task.id}
              className="flex items-center bg-app-card p-3 rounded-lg mb-2 shadow-card transition-all"
            >
              <div className="flex-grow flex items-center cursor-pointer" onClick={() => toggleTask(task.id)}>
                <div
                  className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-3 transition-all ${
                    task.completed ? 'bg-app-accent border-app-accent' : 'border-app-border'
                  }`}
                >
                  {task.completed && (
                    <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
                <span className={`flex-grow ${task.completed ? 'line-through text-app-text-subtle' : 'text-app-text'}`}>
                  {task.text}
                </span>
              </div>
              <button onClick={() => deleteTask(task.id)} className="text-app-text-subtle hover:text-red-500 p-2 rounded-full transition-colors">
                <TrashIcon />
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Tasks;
