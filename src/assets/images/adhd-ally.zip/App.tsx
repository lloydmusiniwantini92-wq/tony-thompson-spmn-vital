import React, { useState } from 'react';
import Tasks from './components/Tasks';
import Focus from './components/Focus';
import BrainDump from './components/BrainDump';
import { TasksIcon, FocusIcon, BrainDumpIcon } from './components/shared/Icons';
import { ActiveTab } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('tasks');

  const renderContent = () => {
    switch (activeTab) {
      case 'tasks':
        return <Tasks />;
      case 'focus':
        return <Focus />;
      case 'dump':
        return <BrainDump />;
      default:
        return <Tasks />;
    }
  };

  const navItems = [
    { id: 'tasks', label: 'Tasks', icon: <TasksIcon /> },
    { id: 'focus', label: 'Focus', icon: <FocusIcon /> },
    { id: 'dump', label: 'Dump', icon: <BrainDumpIcon /> },
  ];

  return (
    <div className="h-full flex flex-col font-sans antialiased">
      <main className="flex-grow overflow-hidden">
        {renderContent()}
      </main>

      <div className="h-24" /> {/* Spacer for tab bar */}

      <footer className="absolute bottom-0 left-0 right-0 h-24 bg-white/70 backdrop-blur-lg border-t border-app-border">
        <nav className="flex justify-around items-center h-full px-4 pb-5">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as ActiveTab)}
              className={`flex flex-col items-center justify-center w-20 h-16 rounded-lg transition-all duration-200 ${
                activeTab === item.id ? 'text-app-primary' : 'text-app-text-subtle'
              }`}
            >
              {item.icon}
              <span className={`text-xs mt-1 font-semibold ${activeTab === item.id ? 'text-app-primary' : ''}`}>{item.label}</span>
            </button>
          ))}
        </nav>
      </footer>
    </div>
  );
};

export default App;
